for i in range(10):
    i+=1
    print(i,end="|")