k = int(input('Введите число : '))
i=1
while k>=i:
    print(i, end=" ")
    i+=1