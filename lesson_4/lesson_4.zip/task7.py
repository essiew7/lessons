num = int(input('Введите число : '))
print(list(range(num,0,-1)))