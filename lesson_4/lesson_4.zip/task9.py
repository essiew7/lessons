word = str(input("Введите слово : "))
print(word[::-1])
    