import string
print(string.ascii_lowercase)
