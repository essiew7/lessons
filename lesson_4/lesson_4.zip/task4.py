num = int(input('Введите число : '))
print(list(range(2,num+1,2)))