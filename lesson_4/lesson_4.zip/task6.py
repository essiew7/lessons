k = int(input('Введите число : '))
for a in range(1,k+1):
    for b in range(1,k+1):
        print(a,'*',b,'=',a*b)