for a in range(1,11):
    for b in range(1,11):
        print(a,'*',b,'=',a*b)