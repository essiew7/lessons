a = input("Введите число : ") # 786501
b = [int(k) for k in a ]
print(f"Максимальная цифра в числе {int(a)} это : {max(b)}")
