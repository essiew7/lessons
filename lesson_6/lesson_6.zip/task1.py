a = ['headphones', 'keyboard', 'mouse']
print(a)
a = [str(x) for x in range(1,4) ]
print(a)