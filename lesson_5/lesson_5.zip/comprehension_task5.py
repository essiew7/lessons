numbers = [[k + 4*i + 1 for k in range(4)] for i in range(3)]
print(numbers)