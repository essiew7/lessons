numbers = [k for k in range(1,101) if k % 3 == 0 and k % 5 == 0]
print(numbers)