def two_nums_sum(a, b):
    num_sum = lambda x: a + b
    return num_sum(0)

print(two_nums_sum(5, 12))