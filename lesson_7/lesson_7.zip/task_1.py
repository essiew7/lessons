def list_squares(data):
   data = [x**2 for x in data]
   print(data)

a = [1,3,5,7,9]
list_squares(a)
        