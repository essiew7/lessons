def digit_check(data):
    data = [k for k in data if k.isdigit()]
    print(data)

a = ["dasda", '123', 'gdfgdf']
digit_check(a)